---

banner_icon: 📖
banner_y: 0.308
banner: "https://imagens.usp.br/wp-content/uploads/IMG_7509.jpg"
conceitos: ['isotopia','figuritivização','tematização','iconização']
expressoesuteis: ['']
---

# TEORIA DO DISCURSO
Diana Luz Pessoa de Barros
%%[[Semiótica Standard]]%%

>[!cite]- Dados sobre este livro 
>
> **Citação:** BARROS, Diana Luz Pessoa de. Teoria do discurso: fundamentos semióticos. 3. ed. São Paulo: Humanitas / FLLCH-USP, 2001.

---

*À Mariana
que descobre a escrita.
À Flávia
que aprende a falar.

##

Escrever algo sobre o livro

O livro pode ser baixado aqui https://filosoficabiblioteca.files.wordpress.com/2020/04/diana-luz-pessoa-de-barros-teoria-do-discurso-fundamentos-semic3b3ticos-doc-rev-1.pdf